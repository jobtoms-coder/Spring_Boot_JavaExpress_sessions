package com.javaexpress.model;

import java.util.Date;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Setter
@Getter
@NoArgsConstructor
public class Product {
	
	
	/*
	 * public Boolean getActive() { return active; }
	 * 
	 * public void setActive(Boolean active) { this.active = active; }
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private Integer id; 
	
	@Column (name = "name")
	private String name; 
	
	private String description;
	

	private Double price; 
	
	private Boolean active; 
	
	@CreationTimestamp
	private Date createdTime; 
	
	@CreationTimestamp
	private Date updatedTime; 
	
	@JsonIgnore
	  @ManyToOne	  
	  @JoinColumn (name = "category_id", nullable = false) 
	  private Category category;
	 
		/*
		 * public Integer getId() { return id; }
		 * 
		 * public void setId(Integer id) { this.id = id; }
		 * 
		 * public String getName() { return name; }
		 * 
		 * public Double getPrice() { return price; }
		 * 
		 * public void setPrice(Double price) { this.price = price; }
		 * 
		 * public Date getCreatedTime() { return createdTime; }
		 * 
		 * public void setCreatedTime(Date createdTime) { this.createdTime =
		 * createdTime; }
		 * 
		 * public Date getUpdatedTime() { return updatedTime; }
		 * 
		 * public void setUpdatedTime(Date updatedTime) { this.updatedTime =
		 * updatedTime; }
		 * 
		 * 
		 * public Category getCategory() { return category; }
		 * 
		 * public void setCategory(Category category) { this.category = category; }
		 * 
		 * 
		 * public void setName(String name) { this.name = name; }
		 * 
		 * public String getDescription() { return description; }
		 * 
		 * public void setDescription(String description) { this.description =
		 * description; }
		 * 
		 */
	
	//@Override
/*	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", description=" + description + ", price=" + price
				+ ", active=" + active + ", createdTime=" + createdTime + ", updatedTime=" + updatedTime + ", category="
				+ category + "]";*/
	//}
	

}
