package com.javaexpress;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.javaexpress.model.Category;
import com.javaexpress.service.CategoryServiceImpl;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class Application {
	
	@Autowired  //Dependency Injection
	private CategoryServiceImpl categoryServiceImpl;
	
	@Autowired  //Dependency Injection
	private Category category;
	


	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	


	@PostConstruct
public void save() {
//Category category = new Category();
		category.setId(2);
category.setName("Mobile");
category.setDescription("Android S23 PLUS MINUS");
//categoryServiceImpl.createCategory(category); 
//
categoryServiceImpl.updateCategory1(category);
//
//Category dbCategory = categoryServiceImpl.fetchCategory(2);
//System.out.println("La La");
//System.out.println(dbCategory);
//	
//categoryServiceImpl.deleteCategory(1);
	}
	
	
	

}
