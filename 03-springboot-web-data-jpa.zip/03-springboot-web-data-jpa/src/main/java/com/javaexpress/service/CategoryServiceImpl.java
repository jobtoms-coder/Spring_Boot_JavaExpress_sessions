package com.javaexpress.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javaexpress.model.Category;
import com.javaexpress.repository.CategoryRepository;

@Service //@Entity, @Service, etc. are Stereotype annotations //Business Logic
public class CategoryServiceImpl {
	
	@Autowired  //Dependency Injection
	private CategoryRepository categoryRepository; 
	
	public void createCategory(Category category) {
		categoryRepository.save(category);		
	}
	
//	public void updateCategory(Category category) {
//		Optional <Category>optionalCat = categoryRepository.findById(category.getId());
//		if (optionalCat.isPresent()) {
//			
//			Category dbCategory = optionalCat.get();
//			dbCategory.setName(category.getName());
//			dbCategory.setDescription(category.getDescription());
//			categoryRepository.save(category);		
//			
//		}
//		else {
//			throw new RuntimeException("Category Id not found in DB"+category.getId());
//		}		
//		
//	}
	
	public void updateCategory1(Category category) {
		Category dbCategory = fetchCategory(category.getId());
		
		dbCategory.setName(category.getName());
		dbCategory.setDescription(category.getDescription());
		categoryRepository.save(category);
		
		//categoryRepository.save(dbCategory);
		                 
		
	}
	
	public Category fetchCategory (Integer id) {
		
	Optional<Category> optionCat =  categoryRepository.findById(id);
	
	 if (optionCat.isPresent()) {
		 return optionCat.get();
	 } 
	 else {
		 throw new RuntimeException ("Category Id Not found in DB" + id);
	 }
	

}
	
	public Boolean deleteCategory(Integer id) {
		
		Category dbCategory = fetchCategory(id);
		categoryRepository.delete(dbCategory);
		return true;
	}
		
	
}
