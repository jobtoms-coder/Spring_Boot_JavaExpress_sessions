package com.javaexpress.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import com.javaexpress.model.Product;
import com.javaexpress.repository.CategoryRepository;
import com.javaexpress.repository.ProductRepository;

@Service // Business Logic
public class ProductServiceImpl {
	
	@Autowired //for Dependency Injection
	private ProductRepository productRepository; 
	
	
	public void create (Product product) {
		System.out.println("id is " + product.getId()); 
		System.out.println("description is " + product.getDescription());
		System.out.println("Active is " + product.getActive());
		
		System.out.println("category_id is " + product.getCategory().getId());
		System.out.println("price is " + product.getPrice());
		productRepository.save(product);
	}
	
	public Product fetch(Integer id) {
		
		System.out.println("In the fetch method of ProductServiceImpl " + id);
		return productRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Product Not Exist in DB"));
		
	}

}
